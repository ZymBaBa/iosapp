angular.module('starter.config', [])
  .constant("YW",{
    //常规的配置项
    "debug":false,
    "api":"http://localhost:8087/hands/",
    //"api":"http://www.hemastu.com:8080/hands-app/",
    // "api":"http://192.168.31.187:8080/hands-app/",
    "imgUrl":"",
    "version":"1.0",
    "userKey":"user"
  });


