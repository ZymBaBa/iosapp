angular.module('starter.HomeCtrl', [])

  .controller('HomeCtrl', ['$scope', '$resource', '$ionicLoading', '$timeout', 'homeFactory', '$ionicModal','$rootScope','$state', 'YW',function ($scope, $resource, $ionicLoading, $timeout, homeFactory, $ionicModal,$rootScope,$state,YW) {
    //广播拿到城市编号、经伟度坐标



    var url=YW.api;
    var getUlr = $resource(url+'recruit/list',{id:'330400',locationLng:'11111',locationLat:'222222'});
    $ionicLoading.show({
      template: '数据载入中，请稍等......',
      noBackdrop: true,
      delay: 500
    });
    $timeout(function () {
      getUlr.get(function (data) {
        $scope.items = data.rows;
      });
      $ionicLoading.hide()
    }, 1500);
    //下拉更新
    $scope.doRefresh = function () {
      //这里写下拉更新请求的代码
      $scope.$broadcast("scroll.refreshComplete")
    };
    //上拉更新
    $scope.load_more = function () {
      //这里放上拉更新请求的代码
      $scope.$broadcast("scroll.infiniteScrollComplete")
    };

    //帮我找兼职
    //标题
    $scope.Title = {
      sorts: '岗位选择',
      send: '薪酬要求',
      city: '选择城市'
    };
    var jobUrl = 'json/joblist.json';
    var getJobUlr = $resource(jobUrl);
    $timeout(function () {
      getJobUlr.get(function (data) {
        $scope.jobs = data.rows;
      });
      $ionicLoading.hide()
    }, 1000);
    //分类选择
    $ionicModal.fromTemplateUrl("sorts-modal.html", {
      scope: $scope,
      animation: "slide-in-up"
    }).then(function (modal) {
      $scope.sorts = modal
    });
    $scope.openSorts = function () {
      if($rootScope.state){
        $scope.sorts.show();
      }else{
        $state.go("login")
      }
    };
    $scope.closeSorts = function () {
      $scope.sorts.hide()
    };
    //薪酬选择
    $ionicModal.fromTemplateUrl("send-modal.html", {
      scope: $scope,
      animation: "slide-in-up"
    }).then(function (modal) {
      $scope.send = modal
    });
    $scope.openSend = function () {
      $scope.send.show();
    };
    $scope.closeSend = function () {
      $scope.send.hide();
    };
    $scope.ret = {choice: "推广员"};
    //列表
    $scope.devList = [
      {text: "嘉兴禾码科技服务有限公司", checked: false},
      {text: "浙江禾码教育咨询科技服务有限公司", checked: false},
      {text: "上海圣龙马科技服务有限公司", checked: false}
    ];
    //城市选择
    $ionicModal.fromTemplateUrl("city-modal.html", {
      scope: $scope,
      animation: "slide-in-up"
    }).then(function (modal) {
      $scope.city = modal
    });
    $scope.openCity = function () {
      $scope.city.show();
    };
    $scope.closeCity = function () {
      $scope.city.hide();
    };
    var cityUrl = 'json/citylist.json';
    var getCityUlr = $resource(cityUrl);
    $timeout(function () {
      getCityUlr.get(function (data) {
        $scope.cityItems = data.rows;
      });
      $ionicLoading.hide()
    }, 1000);
  }]);
