angular.module('starter.UserCtrl', [])
  .controller('UserCtrl', ['$scope', '$resource', '$state', '$ionicModal', 'Storage', function ($scope, $resource, $state, $ionicModal, Storage) {
    var localKey = 'user';
    $scope.user = Storage.get(localKey);
    $scope.$on('$ionicView.beforeEnter', function () {

    })
  }])
  //我的简历
  .controller('ReumeCtrl', ['$scope', '$ionicModal', function ($scope, $ionicModal) {
    //新增简历
    $scope.nRTitle = '新增简历';
    $ionicModal.fromTemplateUrl("newReume-modal.html", {
      scope: $scope,
      animation: "slide-in-up"
    }).then(function (modal) {
      $scope.newReume = modal
    });
    $scope.openNr = function () {
      $scope.newReume.show();
    };
    $scope.closeNr = function () {
      $scope.newReume.hide()
    };
  }])
  //兼职历程
  .controller('CouresCtrl', ['$scope', '$resource', '$ionicPopover', '$ionicLoading', '$timeout', '$ionicPopup', function ($scope, $resource, $ionicPopover, $ionicLoading, $timeout, $ionicPopup) {
    var url = 'json/coures.json';
    var getUlr = $resource(url);

    $ionicLoading.show({
      template: '数据载入中，请稍等......',
      noBackdrop: true,
      delay: 300
    });
    $timeout(function () {
      getUlr.get(function (data) {
        $scope.items = data.rows;
      });
      $ionicLoading.hide()
    }, 1000);

//下拉更新
    $scope.doRefresh = function () {
      //you code
      $scope.$broadcast("scroll.refreshComplete")
    };
//Popover 弹出框代码
    $ionicPopover.fromTemplateUrl("jobInvite-popover.html", {
      scope: $scope
    })
      .then(function (popover) {
        $scope.popover = popover;
      });
    //打开对话框，并且取到相应对象的数据
    $scope.openPopover = function ($event, item) {
      $scope.popover.show($event);
      $scope.userList = item;
    };
    //拨打电话
    $scope.dialPhone = function (touchName, phone) {
      $scope.popover.hide();
      $ionicPopup.confirm({
        title: "联系面试官",
        template: "<p class='text-center' style='color:#10ac86'>" + touchName + "-" + phone + "</p>",
        okText: "拨号",
        okType: "button-balanced",
        cancelText: '取消',
        cancelType: "button-light"
      })
    };
    //查看评价
    $scope.seeConfirm = function (data) {
      $scope.popover.hide();
      $ionicPopup.alert({
        title: "兼职评价",
        template: "<div>" + data + "</div>",
        okText: "知了",
        okType: "button-balanced"
      })
    };
  }])
  //兼职收藏
  .controller('CollectionCtrl', ['$scope', function ($scope) {
    $scope.name = 'CollectionCtrl';
  }])
  //关于我们
  .controller('AboutCtrl', ['$scope', function ($scope) {
    $scope.name = 'AboutCtrl';
  }]);
