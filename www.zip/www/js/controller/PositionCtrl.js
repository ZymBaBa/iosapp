angular.module('starter.PositionCtrl', [])

.controller('PositionCtrl', ['$scope','$resource',function($scope,$resource) {



}]);

